# Projet d'implémentation des algorithmes de calculs de cercle minimum.
# Par Adil Rouichi et Vahe Avetissian


### Execution

Désolé mais je n'ai pas réussi à lancer ce projet et ses dépendances en ligne de commande via "javac".
-Veuillez ouvrir le projet avec un IDE adapté puis ajouter les librairies jcommon et jfreechart (qui se trouvent à la racine du projet) aux dépendances.

Enfin, veuillez pouvez modifier dans le main les valeur de :
=> instancesCount qui correspond au nombre d'instances de tests utilisées (max 1664).
=> instancePointsCount qui correspond au nombre de points utilisés pour chaque fichier (max 255).
=> folder qui correspond au chemin absolu vers le fichier contenant les instances de test.


### Merci et bonne continuation.